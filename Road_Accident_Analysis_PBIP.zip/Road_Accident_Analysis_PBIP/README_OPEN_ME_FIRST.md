# Road Accident Analysis: Power BI project (PBIP)

A real .pbix is a proprietary binary that can only be written by Power BI Desktop, so this is a
Power BI **Project** (text-based PBIP). Power BI Desktop opens it and saves it as .pbix in one step.

## Open it (3 minutes)
1. Power BI Desktop (Windows, up to date) -> File -> Options and settings -> Options -> Preview features:
   tick **Power BI Project (.pbip) save option** and **Store semantic model using TMDL format**. Restart.
2. Unzip this folder somewhere permanent, e.g. `C:\Projects\Road_Accident_Analysis_PBIP`.
3. Double-click `Road_Accident_Analysis.pbip`.
4. If a data error appears: Home -> Transform data -> Edit parameters -> set **CsvPath** to the full path of
   `data\accident_cleaned.csv` (e.g. `C:\Projects\Road_Accident_Analysis_PBIP\data\accident_cleaned.csv`) -> OK -> Close & Apply.
5. **File -> Save as -> Power BI report (.pbix)** -> this is your downloadable dashboard file.

## What is inside
- Model: `Accidents` (59,998 rows) + `Calendar` table, relationship on date, 14 DAX measures
  (Total Accidents, Fatal Rate %, Serious+Fatal %, Avg Casualties, Dark Conditions %, Wet or Icy Surface %, etc.).
- Power Query adds sort helpers (severity_rank, day_num, time_band_order), light_group, day_type.
- 4 pages, 66 visuals: Overview, Time Patterns, Road & Conditions, Details. Slicers on every page, cross-filtering, page navigation buttons.
- Accessibility (WCAG-oriented): alt text on every visual, tooltips on nav buttons, tab order in reading order.

## Data cautions
- `accident_cleaned.csv` was uploaded empty, so it was rebuilt from the data embedded in your HTML dashboard (59,998 rows, unique accident_id, 2018 only).
- 1 row has a blank hour/time_band (shown as "Unknown").
- Latitude/longitude fall in India but road attributes (mph-style speed limits, frost, snow, "dual carriageway")
  look UK-style. No map is included; validate the geography before adding one.
- Counts are not risk. Rates need exposure data (traffic volume or road length).

## Not tested in Desktop
This project was generated and validated as JSON/TMDL, but could not be opened in Power BI Desktop here.
If Desktop reports a problem, tell me the exact message and I will fix it.
